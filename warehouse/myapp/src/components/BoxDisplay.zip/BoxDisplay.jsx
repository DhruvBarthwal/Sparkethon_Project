import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { useLocation, useNavigate } from "react-router-dom";

// Manual OrbitControls implementation to avoid import issues
class OrbitControls {
  constructor(camera, domElement) {
    this.camera = camera;
    this.domElement = domElement;
    this.enableDamping = true;
    this.dampingFactor = 0.05;
    this.minDistance = 1;
    this.maxDistance = 100;
    this.autoRotate = false;
    this.autoRotateSpeed = 2.0;
    
    this.target = new THREE.Vector3();
    this.spherical = new THREE.Spherical();
    this.sphericalDelta = new THREE.Spherical();
    this.scale = 1;
    this.panOffset = new THREE.Vector3();
    this.zoomChanged = false;
    
    this.rotateStart = new THREE.Vector2();
    this.rotateEnd = new THREE.Vector2();
    this.rotateDelta = new THREE.Vector2();
    
    this.panStart = new THREE.Vector2();
    this.panEnd = new THREE.Vector2();
    this.panDelta = new THREE.Vector2();
    
    this.dollyStart = new THREE.Vector2();
    this.dollyEnd = new THREE.Vector2();
    this.dollyDelta = new THREE.Vector2();
    
    this.state = 'NONE';
    this.keys = { LEFT: 37, UP: 38, RIGHT: 39, BOTTOM: 40 };
    this.mouseButtons = { LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN };
    
    this.getAutoRotationAngle = () => 2 * Math.PI / 60 / 60 * this.autoRotateSpeed;
    this.getZoomScale = () => Math.pow(0.95, 1);
    
    this.rotateLeft = (angle) => { this.sphericalDelta.theta -= angle; };
    this.rotateUp = (angle) => { this.sphericalDelta.phi -= angle; };
    this.dollyIn = (dollyScale) => { this.scale /= dollyScale; };
    this.dollyOut = (dollyScale) => { this.scale *= dollyScale; };
    
    this.update = () => {
      const position = this.camera.position;
      const offset = position.clone().sub(this.target);
      
      this.spherical.setFromVector3(offset);
      
      if (this.autoRotate && this.state === 'NONE') {
        this.rotateLeft(this.getAutoRotationAngle());
      }
      
      this.spherical.theta += this.sphericalDelta.theta;
      this.spherical.phi += this.sphericalDelta.phi;
      
      this.spherical.makeSafe();
      this.spherical.radius *= this.scale;
      this.spherical.radius = Math.max(this.minDistance, Math.min(this.maxDistance, this.spherical.radius));
      
      this.target.add(this.panOffset);
      offset.setFromSpherical(this.spherical);
      position.copy(this.target).add(offset);
      
      this.camera.lookAt(this.target);
      
      if (this.enableDamping === true) {
        this.sphericalDelta.theta *= (1 - this.dampingFactor);
        this.sphericalDelta.phi *= (1 - this.dampingFactor);
      } else {
        this.sphericalDelta.set(0, 0, 0);
      }
      
      this.scale = 1;
      this.panOffset.set(0, 0, 0);
      
      if (this.zoomChanged) {
        this.zoomChanged = false;
        return true;
      }
      
      return false;
    };
    
    // Mouse event handlers
    this.onMouseDown = (event) => {
      if (event.button === 0) {
        this.state = 'ROTATE';
        this.rotateStart.set(event.clientX, event.clientY);
      } else if (event.button === 1) {
        this.state = 'DOLLY';
        this.dollyStart.set(event.clientX, event.clientY);
      } else if (event.button === 2) {
        this.state = 'PAN';
        this.panStart.set(event.clientX, event.clientY);
      }
    };
    
    this.onMouseMove = (event) => {
      switch (this.state) {
        case 'ROTATE':
          this.rotateEnd.set(event.clientX, event.clientY);
          this.rotateDelta
            .subVectors(this.rotateEnd, this.rotateStart)
            .multiplyScalar(0.01);

          this.rotateLeft(
            (2 * Math.PI * this.rotateDelta.x) / this.domElement.clientHeight
          );
          this.rotateUp(
            (2 * Math.PI * this.rotateDelta.y) / this.domElement.clientHeight
          );

          this.rotateStart.copy(this.rotateEnd);
          break;

        case 'PAN':
          this.panEnd.set(event.clientX, event.clientY);
          this.panDelta
            .subVectors(this.panEnd, this.panStart)
            .multiplyScalar(0.005 * this.spherical.radius);

          const panOffset = new THREE.Vector3();
          panOffset.setFromMatrixColumn(this.camera.matrix, 0); // x-axis
          panOffset.multiplyScalar(-this.panDelta.x);
          this.panOffset.add(panOffset);

          panOffset.setFromMatrixColumn(this.camera.matrix, 1); // y-axis
          panOffset.multiplyScalar(this.panDelta.y);
          this.panOffset.add(panOffset);

          this.panStart.copy(this.panEnd);
          break;

        case 'DOLLY':
          this.dollyEnd.set(event.clientX, event.clientY);
          this.dollyDelta.subVectors(this.dollyEnd, this.dollyStart);

          if (this.dollyDelta.y > 0) {
            this.dollyIn(this.getZoomScale());
          } else if (this.dollyDelta.y < 0) {
            this.dollyOut(this.getZoomScale());
          }

          this.dollyStart.copy(this.dollyEnd);
          break;
      }
    };
    
    this.onMouseUp = () => {
      this.state = 'NONE';
    };
    
    this.onWheel = (event) => {
      if (event.deltaY < 0) {
        this.dollyOut(this.getZoomScale());
      } else if (event.deltaY > 0) {
        this.dollyIn(this.getZoomScale());
      }
      this.zoomChanged = true;
    };
    
    this.domElement.addEventListener('mousedown', this.onMouseDown);
    this.domElement.addEventListener('mousemove', this.onMouseMove);
    this.domElement.addEventListener('mouseup', this.onMouseUp);
    this.domElement.addEventListener('wheel', this.onWheel);
    this.domElement.addEventListener('contextmenu', (e) => e.preventDefault());
  }
  
  dispose() {
    this.domElement.removeEventListener('mousedown', this.onMouseDown);
    this.domElement.removeEventListener('mousemove', this.onMouseMove);
    this.domElement.removeEventListener('mouseup', this.onMouseUp);
    this.domElement.removeEventListener('wheel', this.onWheel);
  }
}

const BoxDisplay = () => {
  const mountRef = useRef(null);
  const location = useLocation();
  const navigate = useNavigate();
  const { boxSize } = location.state || {};
  
  const [currentStep, setCurrentStep] = useState(3); // Start with full box (step 3)
  const [isAnimating, setIsAnimating] = useState(false);
  const [animationProgress, setAnimationProgress] = useState(0);
  
  // Step definitions with updated names
  const steps = [
    { name: "Empty Box", description: "Starting with an empty container", count: 0 },
    { name: "Bags", description: "Adding 9 bags to the bottom layer", count: 9 },
    { name: "Kits", description: "Placing 3 kits in the middle layer", count: 3 },
    { name: "Volleyballs", description: "Completing with 2 volleyballs on top", count: 2 }
  ];

  const sceneRef = useRef(null);
  const meshesRef = useRef([]);
  const rendererRef = useRef(null);
  const cameraRef = useRef(null);
  const controlsRef = useRef(null);

  useEffect(() => {
    if (!boxSize || !mountRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf0f9ff);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(
      50,
      mountRef.current.clientWidth / mountRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.set(boxSize * 2, boxSize * 1.8, boxSize * 2);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ 
      antialias: true, 
      alpha: true,
      powerPreference: "high-performance"
    });
    renderer.setSize(
      mountRef.current.clientWidth,
      mountRef.current.clientHeight
    );
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    mountRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = boxSize;
    controls.maxDistance = boxSize * 4;
    controls.autoRotate = false;
    controls.autoRotateSpeed = 0.2;
    controlsRef.current = controls;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1.2);
    mainLight.position.set(15, 20, 10);
    mainLight.castShadow = true;
    mainLight.shadow.mapSize.width = 1024;
    mainLight.shadow.mapSize.height = 1024;
    scene.add(mainLight);

    const rimLight = new THREE.DirectionalLight(0x4f46e5, 0.8);
    rimLight.position.set(-10, 5, -10);
    scene.add(rimLight);

    // Container
    const containerGeometry = new THREE.BoxGeometry(boxSize, boxSize, boxSize);
    const containerMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      metalness: 0.1,
      roughness: 0.1,
      transmission: 0.9,
      transparent: true,
      opacity: 0.15,
      thickness: 0.5,
      ior: 1.5,
    });

    const container = new THREE.Mesh(containerGeometry, containerMaterial);
    scene.add(container);

    const wireframe = new THREE.EdgesGeometry(containerGeometry);
    const wireframeMaterial = new THREE.LineBasicMaterial({ 
      color: 0x1e293b,
      opacity: 0.3,
      transparent: true
    });
    const containerWireframe = new THREE.LineSegments(wireframe, wireframeMaterial);
    scene.add(containerWireframe);

    // Ground
    const groundGeometry = new THREE.PlaneGeometry(boxSize * 3, boxSize * 3);
    const groundMaterial = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      metalness: 0.1,
      roughness: 0.8,
      transparent: true,
      opacity: 0.8
    });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -boxSize / 2 - 0.1;
    ground.receiveShadow = true;
    scene.add(ground);

    // Create all meshes and add them to scene immediately (full box)
    createAllMeshes();
    addAllMeshesToScene();

    // Animation loop
    const animate = () => {
      controls.update();
      renderer.render(scene, camera);
      requestAnimationFrame(animate);
    };
    animate();

    const handleResize = () => {
      if (!mountRef.current) return;
      
      camera.aspect = mountRef.current.clientWidth / mountRef.current.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (controls) controls.dispose();
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [boxSize]);

  const createAllMeshes = () => {
    const meshes = [];

    // Enhanced color palette
    const colorPalettes = {
      cylinder: { color: '#ef4444', metalness: 0.3, roughness: 0.2 },
      cuboid: { color: '#8b5cf6', metalness: 0.4, roughness: 0.1 },
      sphere: { color: '#f59e0b', metalness: 0.2, roughness: 0.3 }
    };

    const gap = 0.01 * boxSize;
    const unit = boxSize / 3;

    // BAGS (Cylinders - 9 total)
    for (let x = 0; x < 3; x++) {
      for (let z = 0; z < 3; z++) {
        const cylinderGeometry = new THREE.CylinderGeometry(
          unit * 0.48,
          unit * 0.48,
          unit * 0.9,
          16
        );
        
        const cylinderMaterial = new THREE.MeshPhysicalMaterial({
          color: new THREE.Color(colorPalettes.cylinder.color),
          metalness: colorPalettes.cylinder.metalness,
          roughness: colorPalettes.cylinder.roughness,
          clearcoat: 0.3,
          clearcoatRoughness: 0.1,
        });

        const cylinder = new THREE.Mesh(cylinderGeometry, cylinderMaterial);
        cylinder.castShadow = true;
        cylinder.receiveShadow = true;

        const finalPos = {
          x: -boxSize / 2 + gap + unit / 2 + x * unit,
          y: -boxSize / 2 + gap + (unit * 0.9) / 2,
          z: -boxSize / 2 + gap + unit / 2 + z * unit,
        };

        cylinder.position.set(finalPos.x, finalPos.y, finalPos.z);
        cylinder.userData = {
          targetPos: finalPos,
          targetRotation: { x: 0, y: 0, z: 0 },
          type: 'cylinder',
          step: 1,
          index: x * 3 + z
        };

        meshes.push({ mesh: cylinder, type: 'cylinder', step: 1 });
      }
    }

    // KITS (Cuboids - 3 total)
    const cuboidPositions = [
      { x: 0, z: 0 },
      { x: 1, z: 0 },
      { x: 2, z: 0 }
    ];

    cuboidPositions.forEach(({ x, z }, index) => {
      const cuboidGeometry = new THREE.BoxGeometry(
        unit * 0.8,
        unit * 0.8,
        unit * 2.8
      );
      
      const cuboidMaterial = new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(colorPalettes.cuboid.color),
        metalness: colorPalettes.cuboid.metalness,
        roughness: colorPalettes.cuboid.roughness,
        clearcoat: 0.3,
        clearcoatRoughness: 0.1,
      });

      const cuboid = new THREE.Mesh(cuboidGeometry, cuboidMaterial);
      cuboid.castShadow = true;
      cuboid.receiveShadow = true;

      const finalPos = {
        x: -boxSize / 2 + gap + unit / 2 + x * unit,
        y: -boxSize / 2 + gap + unit * 0.9 + (unit * 0.8) / 2,
        z: 0,
      };

      cuboid.position.set(finalPos.x, finalPos.y, finalPos.z);
      cuboid.userData = {
        targetPos: finalPos,
        targetRotation: { x: 0, y: 0, z: 0 },
        type: 'cuboid',
        step: 2,
        index: index
      };

      const edgeGeometry = new THREE.EdgesGeometry(cuboidGeometry);
      const edgeMaterial = new THREE.LineBasicMaterial({ 
        color: 0x1f2937,
        opacity: 0.8,
        transparent: true
      });
      const edges = new THREE.LineSegments(edgeGeometry, edgeMaterial);
      edges.position.copy(cuboid.position);

      meshes.push({ mesh: cuboid, edges, type: 'cuboid', step: 2 });
    });

    // VOLLEYBALLS (Spheres - 2 total)
    const spherePositions = [
      { x: 0.5, z: 0.5 },
      { x: 1.5, z: 1.5 }
    ];

    spherePositions.forEach(({ x, z }, index) => {
      const sphereGeometry = new THREE.SphereGeometry(unit * 0.6, 16, 12);
      
      const sphereMaterial = new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(colorPalettes.sphere.color),
        metalness: colorPalettes.sphere.metalness,
        roughness: colorPalettes.sphere.roughness,
        clearcoat: 0.5,
        clearcoatRoughness: 0.05,
      });

      const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
      sphere.castShadow = true;
      sphere.receiveShadow = true;

      const finalPos = {
        x: -boxSize / 2 + gap + unit / 2 + x * unit,
        y: -boxSize / 2 + gap + unit * 0.9 + unit * 0.8 + unit * 0.6,
        z: -boxSize / 2 + gap + unit / 2 + z * unit,
      };

      sphere.position.set(finalPos.x, finalPos.y, finalPos.z);
      sphere.userData = {
        targetPos: finalPos,
        type: 'sphere',
        step: 3,
        index: index
      };

      meshes.push({ mesh: sphere, type: 'sphere', step: 3 });
    });

    meshesRef.current = meshes;
  };

  const addAllMeshesToScene = () => {
    const scene = sceneRef.current;
    meshesRef.current.forEach(({ mesh, edges }) => {
      scene.add(mesh);
      if (edges) scene.add(edges);
    });
  };

  const animateStep = (stepNumber) => {
    if (isAnimating || stepNumber === currentStep) return;
    
    setIsAnimating(true);
    setAnimationProgress(0);
    
    const scene = sceneRef.current;
    
    if (stepNumber > currentStep) {
      // Adding objects
      const meshesToAnimate = meshesRef.current.filter(item => item.step === stepNumber);
      
      meshesToAnimate.forEach(({ mesh, edges }, index) => {
        // Set initial position above the box
        mesh.position.set(
          mesh.userData.targetPos.x + (Math.random() - 0.5) * 0.3,
          boxSize / 2 + 2 + Math.random() * 1,
          mesh.userData.targetPos.z + (Math.random() - 0.5) * 0.3
        );
        
        if (mesh.userData.targetRotation) {
          mesh.rotation.set(
            Math.random() * 0.2,
            Math.random() * 0.2,
            Math.random() * 0.2
          );
        }
        
        // Add to scene
        scene.add(mesh);
        if (edges) {
          edges.position.copy(mesh.position);
          edges.rotation.copy(mesh.rotation);
          scene.add(edges);
        }
        
        // Initialize animation properties
        mesh.userData.velocity = { x: 0, y: 0, z: 0 };
        mesh.userData.rotationVelocity = { x: 0, y: 0, z: 0 };
        mesh.userData.hasLanded = false;
        mesh.userData.delay = index * 0.05; // Reduced delay
      });
      
      // Animation loop for this step
      let time = 0;
      const animateObjects = () => {
        time += 0.02; // Increased time step for faster animation
        let landedCount = 0;
        
        meshesToAnimate.forEach(({ mesh, edges }) => {
          const userData = mesh.userData;
          
          if (time < userData.delay) return;
          
          if (!userData.hasLanded) {
            const gravity = 0.03; // Increased gravity
            const damping = 0.92; // Reduced damping for faster settling
            const attraction = 0.15; // Increased attraction

            const deltaX = userData.targetPos.x - mesh.position.x;
            const deltaY = userData.targetPos.y - mesh.position.y;
            const deltaZ = userData.targetPos.z - mesh.position.z;

            userData.velocity.x += deltaX * attraction;
            userData.velocity.y -= gravity;
            userData.velocity.y += deltaY * attraction;
            userData.velocity.z += deltaZ * attraction;

            userData.velocity.x *= damping;
            userData.velocity.y *= damping;
            userData.velocity.z *= damping;

            mesh.position.x += userData.velocity.x;
            mesh.position.y += userData.velocity.y;
            mesh.position.z += userData.velocity.z;

            if (userData.type !== 'sphere' && userData.rotationVelocity) {
              userData.rotationVelocity.x += (userData.targetRotation.x - mesh.rotation.x) * 0.08;
              userData.rotationVelocity.y += (userData.targetRotation.y - mesh.rotation.y) * 0.08;
              userData.rotationVelocity.z += (userData.targetRotation.z - mesh.rotation.z) * 0.08;

              userData.rotationVelocity.x *= 0.92;
              userData.rotationVelocity.y *= 0.92;
              userData.rotationVelocity.z *= 0.92;

              mesh.rotation.x += userData.rotationVelocity.x;
              mesh.rotation.y += userData.rotationVelocity.y;
              mesh.rotation.z += userData.rotationVelocity.z;
            }

            const distance = Math.sqrt(deltaX*deltaX + deltaY*deltaY + deltaZ*deltaZ);
            if (distance < 0.15 && Math.abs(userData.velocity.y) < 0.05) { // Relaxed landing conditions
              mesh.position.set(userData.targetPos.x, userData.targetPos.y, userData.targetPos.z);
              if (userData.targetRotation) {
                mesh.rotation.set(0, 0, 0);
              }
              userData.hasLanded = true;
              
              // Landing effect
              mesh.scale.setScalar(1.05);
              setTimeout(() => {
                mesh.scale.setScalar(1);
              }, 50); // Reduced effect duration
            }

            if (edges) {
              edges.position.copy(mesh.position);
              edges.rotation.copy(mesh.rotation);
            }
          } else {
            landedCount++;
          }
        });
        
        const progress = Math.min(landedCount / meshesToAnimate.length, 1);
        setAnimationProgress(progress);
        
        if (progress === 1) {
          setIsAnimating(false);
          setCurrentStep(stepNumber);
          return;
        }
        
        requestAnimationFrame(animateObjects);
      };
      
      animateObjects();
    } else {
      // Removing objects (going backwards)
      const meshesToRemove = meshesRef.current.filter(item => item.step > stepNumber);
      
      meshesToRemove.forEach(({ mesh, edges }) => {
        scene.remove(mesh);
        if (edges) scene.remove(edges);
      });
      
      setCurrentStep(stepNumber);
      setIsAnimating(false);
    }
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      animateStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      animateStep(currentStep - 1);
    }
  };

  const handleClose = () => navigate(-1);

  if (!boxSize) {
    return (
      <div className="flex items-center justify-center h-screen bg-gradient-to-br from-slate-900 to-slate-800">
        <div className="text-center">
          <div className="text-6xl mb-4">📦</div>
          <p className="text-slate-300 text-xl font-light">
            No box data found
          </p>
          <button 
            onClick={() => navigate(-1)}
            className="mt-4 px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 z-50 overflow-hidden">
      {/* Loading overlay during animation */}
      {isAnimating && (
        <div className="absolute inset-0 bg-black/20 backdrop-blur-sm z-10 flex items-center justify-center pointer-events-none">
          <div className="bg-white/90 backdrop-blur-md rounded-2xl p-6 shadow-2xl">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-blue-200 rounded-full animate-spin border-t-blue-500 mx-auto mb-3"></div>
              <h3 className="text-lg font-bold text-slate-800 mb-2">
                {currentStep < 3 ? steps[currentStep + 1]?.name : "Updating..."}
              </h3>
              <p className="text-slate-600 text-sm mb-3">
                {currentStep < 3 ? steps[currentStep + 1]?.description : "Adjusting layout..."}
              </p>
              <div className="w-32 h-1.5 bg-blue-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-blue-400 to-blue-600 transition-all duration-200 ease-out"
                  style={{ width: `${animationProgress * 100}%` }}
                ></div>
              </div>
              <p className="text-blue-600 text-xs mt-2">{Math.round(animationProgress * 100)}% Complete</p>
            </div>
          </div>
        </div>
      )}

      <div className="relative w-full h-full">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-6 right-6 z-20 group bg-white/20 backdrop-blur-md border border-white/20 hover:bg-white/30 transition-all duration-300 rounded-2xl w-14 h-14 text-2xl text-slate-700 font-light flex items-center justify-center shadow-2xl hover:shadow-blue-500/25 hover:scale-110"
        >
          <span className="group-hover:rotate-90 transition-transform duration-300">×</span>
        </button>

        {/* Title */}
        <div className="absolute top-6 left-6 z-20">
          <h1 className="text-2xl font-bold text-slate-800 mb-1">3D Step-by-Step Assembly</h1>
          <p className="text-slate-600 text-sm">Interactive Geometric Placement</p>
        </div>

        {/* 3D Canvas */}
        <div ref={mountRef} className="w-full h-full" />

        {/* Right Side Navigation Panel */}
        <div className="absolute top-1/2 right-6 transform -translate-y-1/2 z-20 flex flex-col gap-4">
          {/* Step Info */}
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 shadow-2xl w-80">
            <div className="flex items-center mb-4">
              <div className="w-3 h-3 bg-green-400 rounded-full mr-2 animate-pulse"></div>
              <span className="text-slate-700 font-semibold">
                Step {currentStep + 1} of {steps.length}
              </span>
            </div>
            
            <h3 className="text-lg font-bold text-slate-800 mb-2">
              {steps[currentStep].name}
            </h3>
            <p className="text-slate-600 text-sm mb-4">
              {steps[currentStep].description}
            </p>

            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="bg-white/20 rounded-xl p-3">
                <p className="text-slate-600 text-xs uppercase tracking-wide mb-1">Container Size</p>
                <p className="text-slate-800 font-bold text-lg">
                  {boxSize.toFixed(1)}"
                </p>
              </div>
              <div className="bg-white/20 rounded-xl p-3">
                <p className="text-slate-600 text-xs uppercase tracking-wide mb-1">Objects Added</p>
                <p className="text-slate-800 font-bold text-lg">
                  {steps.slice(0, currentStep + 1).reduce((sum, step) => sum + step.count, 0)}
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-white/20 text-xs text-slate-500">
              <p>💡 Left click + drag to rotate • Right click + drag to pan • Scroll to zoom</p>
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 shadow-2xl w-80">
            <div className="flex flex-col gap-3">
              <div className="text-center mb-2">
                <p className="text-slate-700 font-semibold text-sm">Navigation</p>
              </div>
              
              <div className="flex gap-3">
                <button
                  onClick={handlePrevious}
                  disabled={currentStep === 0 || isAnimating}
                  className="flex-1 bg-slate-600 hover:bg-slate-700 disabled:bg-slate-400 disabled:cursor-not-allowed text-white px-4 py-3 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-xl disabled:shadow-none"
                >
                  ← Previous
                </button>
                
                <button
                  onClick={handleNext}
                  disabled={currentStep === steps.length - 1 || isAnimating}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 disabled:from-gray-400 disabled:to-gray-500 disabled:cursor-not-allowed text-white px-4 py-3 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-xl disabled:shadow-none"
                >
                  Next →
                </button>
              </div>

              {/* Step Progress */}
              <div className="flex justify-center gap-2 mt-2">
                {steps.map((_, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      index <= currentStep ? 'bg-blue-500' : 'bg-slate-300'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BoxDisplay;